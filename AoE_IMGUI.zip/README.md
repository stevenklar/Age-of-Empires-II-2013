This is a hack base for Age of Empires II (2013)

Features:
- Display each players ressources (Food, Wood, Gold, Stone, Population)
- Display amount of infantry and cavarly each player has
- Easy to extend



Want to contribute but don't know what do do? Here are some tasks:

Easy
- use pattern scanning to get offssets for Main, Game and Maphack
- reverse some more information and add it to the classes (stuff like technologies in research, Waypoints...)

Medium
- reverse functions that can be used for automation
	- Move Unit (Unit moveTo vmt func index is 161) but calling it will desync on multiplayer
	- Train Unit
	- ... 

Hard
- try to fix the god damn desync issues
- reverse voobly (Gaming plattform "serious" AoE2 players use that has an anticheat) 